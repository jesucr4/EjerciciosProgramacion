package examen_Jesus_Cano_Ruiz;

public class Ejercicio02_Primos {

	public static void main(String[] args) {
		//creamos contador para ver cuantos números primos hay del 1 al 100
		//para después crear un array con ese número de posiciones
		int contPrimos = 0;
		int contNumeros = 1;
		for (int i = 1; i<=100; i++) {
			contNumeros++;
			if ( % num == 0 && num % 1 == num) {
				System.out.println("El n�mero " + num + "es primo");
			}else {
				System.out.println("El n�mero" + num + " NO es primo");
			}
			
			
		}

	}

}
