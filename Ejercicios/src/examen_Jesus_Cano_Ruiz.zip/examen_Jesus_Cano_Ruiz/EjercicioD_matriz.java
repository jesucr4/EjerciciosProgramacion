package examen_Jesus_Cano_Ruiz;

public class EjercicioD_matriz {

	public static void main(String[] args) {
		int matriz [][] = new int [10][10];
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz[i].length; j++) {
				matriz [i][j] = i
			}
			}
	}

}
