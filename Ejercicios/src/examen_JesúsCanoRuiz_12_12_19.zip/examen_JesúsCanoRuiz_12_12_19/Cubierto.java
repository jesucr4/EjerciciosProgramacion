package examen_JesúsCanoRuiz_12_12_19;

public class Cubierto extends Objeto {

	public Cubierto(int id_Objeto) {
		super(id_Objeto);
		// TODO Auto-generated constructor stub
	}

	@Override
	public Boolean seRompe() {
		// TODO Auto-generated method stub
		return null;
	}

}
